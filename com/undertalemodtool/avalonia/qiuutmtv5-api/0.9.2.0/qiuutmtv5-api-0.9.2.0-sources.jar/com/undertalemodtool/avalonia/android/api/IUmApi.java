/*
 * This file is auto-generated.  DO NOT MODIFY.
 * Using: /usr/local/lib/android/sdk/build-tools/35.0.0/aidl -p/usr/local/lib/android/sdk/platforms/android-35/framework.aidl -o/home/runner/work/QiuUTMTv5-API/QiuUTMTv5-API/umapi/build/generated/aidl_source_output_dir/release/out -I/home/runner/work/QiuUTMTv5-API/QiuUTMTv5-API/umapi/src/main/aidl -I/home/runner/work/QiuUTMTv5-API/QiuUTMTv5-API/umapi/src/release/aidl -d/tmp/aidl16854047513468176577.d /home/runner/work/QiuUTMTv5-API/QiuUTMTv5-API/umapi/src/main/aidl/com/undertalemodtool/avalonia/android/api/IUmApi.aidl
 */
package com.undertalemodtool.avalonia.android.api;
public interface IUmApi extends android.os.IInterface
{
  /** Default implementation for IUmApi. */
  public static class Default implements com.undertalemodtool.avalonia.android.api.IUmApi
  {
    // -- Discovery ---------------------------------------------------------------------------
    // JSON: {ok, apiVersion, appVersion, packageName, descriptor, permission, permissionLevel,
    //        serviceClass, serviceComponent, bindAction, ready, dataLoaded, dataPath, projectName,
    //        runningJobId, activeJobs, scriptRoots[{path, isBuiltIn, exists}]}
    @Override public java.lang.String getApiInfo() throws android.os.RemoteException
    {
      return null;
    }
    // -- Scripts -----------------------------------------------------------------------------
    // JSON: {ok, count, scripts[{name, fileName, relativePath, root, isBuiltIn, fullPath}]}
    @Override public java.lang.String listScripts() throws android.os.RemoteException
    {
      return null;
    }
    // The three start* methods return JSON: {ok, jobId, state, error}
    // scriptText: the csx source itself (at most 512 KB - Binder transactions are capped at 1 MB).
    // name:       display name / script path used in diagnostics ("inline.csx" when empty).
    // optionsJson may be null; supported keys: {"assumeYes": bool} - the answer the host gives to
    // ScriptQuestion confirmations (default false).
    @Override public java.lang.String startScriptText(java.lang.String scriptText, java.lang.String name, java.lang.String optionsJson) throws android.os.RemoteException
    {
      return null;
    }
    // pathOrUri: a filesystem path, a file:// URI or a content:// URI the app is allowed to read.
    @Override public java.lang.String startScriptFile(java.lang.String pathOrUri, java.lang.String optionsJson) throws android.os.RemoteException
    {
      return null;
    }
    // relativePath: as returned by listScripts() - resolved inside the built-in script folders
    // and inside the user script folder (/sdcard/QiuUTMTv5/Scripts) only.
    @Override public java.lang.String startBuiltinScript(java.lang.String relativePath, java.lang.String optionsJson) throws android.os.RemoteException
    {
      return null;
    }
    // -- Jobs --------------------------------------------------------------------------------
    // JSON: {ok, id, kind, name, source, state, queuedAt, startedAt, finishedAt, outputLength,
    //        progress, progressMaximum, progressMessage, progressStatus, returnValue, returnType,
    //        consoleText, error, errorTitle, cancelRequested, assumeYes}
    @Override public java.lang.String getJob(java.lang.String jobId) throws android.os.RemoteException
    {
      return null;
    }
    // Incremental log read; returns JSON {ok, id, state, offset, nextOffset, eof, text}. The caller
    // passes the nextOffset of the previous call to continue reading. Chunks are cut on char
    // boundaries.
    @Override public java.lang.String getJobOutput(java.lang.String jobId, int fromOffset) throws android.os.RemoteException
    {
      return null;
    }
    // Best effort: a queued job stops immediately, a running script stops at its next
    // progress/message call (scripts that never report progress run to completion).
    @Override public boolean cancelJob(java.lang.String jobId) throws android.os.RemoteException
    {
      return false;
    }
    // Blocks the calling (Binder) thread until the job finishes or the timeout elapses;
    // returns true when the job has finished. Call it from a worker thread, not from a UI thread.
    @Override public boolean waitForJob(java.lang.String jobId, long timeoutMillis) throws android.os.RemoteException
    {
      return false;
    }
    // JSON: {ok, count, jobs[...]} - metadata only, no output text.
    @Override public java.lang.String listJobs() throws android.os.RemoteException
    {
      return null;
    }
    // Removes all finished jobs from the list, returns how many were removed.
    @Override public int clearFinishedJobs() throws android.os.RemoteException
    {
      return 0;
    }
    // -- Data files --------------------------------------------------------------------------
    // Both calls block until the file is fully read/written (a large data file can take a while).
    // JSON: {ok, path, dataPath, importantWarnings, warnings[], error}
    @Override public java.lang.String loadDataFile(java.lang.String pathOrUri) throws android.os.RemoteException
    {
      return null;
    }
    // JSON: {ok, path, dataPath, error}
    @Override public java.lang.String saveDataFile(java.lang.String pathOrUri) throws android.os.RemoteException
    {
      return null;
    }
    @Override
    public android.os.IBinder asBinder() {
      return null;
    }
  }
  /** Local-side IPC implementation stub class. */
  public static abstract class Stub extends android.os.Binder implements com.undertalemodtool.avalonia.android.api.IUmApi
  {
    /** Construct the stub at attach it to the interface. */
    @SuppressWarnings("this-escape")
    public Stub()
    {
      this.attachInterface(this, DESCRIPTOR);
    }
    /**
     * Cast an IBinder object into an com.undertalemodtool.avalonia.android.api.IUmApi interface,
     * generating a proxy if needed.
     */
    public static com.undertalemodtool.avalonia.android.api.IUmApi asInterface(android.os.IBinder obj)
    {
      if ((obj==null)) {
        return null;
      }
      android.os.IInterface iin = obj.queryLocalInterface(DESCRIPTOR);
      if (((iin!=null)&&(iin instanceof com.undertalemodtool.avalonia.android.api.IUmApi))) {
        return ((com.undertalemodtool.avalonia.android.api.IUmApi)iin);
      }
      return new com.undertalemodtool.avalonia.android.api.IUmApi.Stub.Proxy(obj);
    }
    @Override public android.os.IBinder asBinder()
    {
      return this;
    }
    @Override public boolean onTransact(int code, android.os.Parcel data, android.os.Parcel reply, int flags) throws android.os.RemoteException
    {
      java.lang.String descriptor = DESCRIPTOR;
      if (code >= android.os.IBinder.FIRST_CALL_TRANSACTION && code <= android.os.IBinder.LAST_CALL_TRANSACTION) {
        data.enforceInterface(descriptor);
      }
      if (code == INTERFACE_TRANSACTION) {
        reply.writeString(descriptor);
        return true;
      }
      switch (code)
      {
        case TRANSACTION_getApiInfo:
        {
          java.lang.String _result = this.getApiInfo();
          reply.writeNoException();
          reply.writeString(_result);
          break;
        }
        case TRANSACTION_listScripts:
        {
          java.lang.String _result = this.listScripts();
          reply.writeNoException();
          reply.writeString(_result);
          break;
        }
        case TRANSACTION_startScriptText:
        {
          java.lang.String _arg0;
          _arg0 = data.readString();
          java.lang.String _arg1;
          _arg1 = data.readString();
          java.lang.String _arg2;
          _arg2 = data.readString();
          java.lang.String _result = this.startScriptText(_arg0, _arg1, _arg2);
          reply.writeNoException();
          reply.writeString(_result);
          break;
        }
        case TRANSACTION_startScriptFile:
        {
          java.lang.String _arg0;
          _arg0 = data.readString();
          java.lang.String _arg1;
          _arg1 = data.readString();
          java.lang.String _result = this.startScriptFile(_arg0, _arg1);
          reply.writeNoException();
          reply.writeString(_result);
          break;
        }
        case TRANSACTION_startBuiltinScript:
        {
          java.lang.String _arg0;
          _arg0 = data.readString();
          java.lang.String _arg1;
          _arg1 = data.readString();
          java.lang.String _result = this.startBuiltinScript(_arg0, _arg1);
          reply.writeNoException();
          reply.writeString(_result);
          break;
        }
        case TRANSACTION_getJob:
        {
          java.lang.String _arg0;
          _arg0 = data.readString();
          java.lang.String _result = this.getJob(_arg0);
          reply.writeNoException();
          reply.writeString(_result);
          break;
        }
        case TRANSACTION_getJobOutput:
        {
          java.lang.String _arg0;
          _arg0 = data.readString();
          int _arg1;
          _arg1 = data.readInt();
          java.lang.String _result = this.getJobOutput(_arg0, _arg1);
          reply.writeNoException();
          reply.writeString(_result);
          break;
        }
        case TRANSACTION_cancelJob:
        {
          java.lang.String _arg0;
          _arg0 = data.readString();
          boolean _result = this.cancelJob(_arg0);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_waitForJob:
        {
          java.lang.String _arg0;
          _arg0 = data.readString();
          long _arg1;
          _arg1 = data.readLong();
          boolean _result = this.waitForJob(_arg0, _arg1);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_listJobs:
        {
          java.lang.String _result = this.listJobs();
          reply.writeNoException();
          reply.writeString(_result);
          break;
        }
        case TRANSACTION_clearFinishedJobs:
        {
          int _result = this.clearFinishedJobs();
          reply.writeNoException();
          reply.writeInt(_result);
          break;
        }
        case TRANSACTION_loadDataFile:
        {
          java.lang.String _arg0;
          _arg0 = data.readString();
          java.lang.String _result = this.loadDataFile(_arg0);
          reply.writeNoException();
          reply.writeString(_result);
          break;
        }
        case TRANSACTION_saveDataFile:
        {
          java.lang.String _arg0;
          _arg0 = data.readString();
          java.lang.String _result = this.saveDataFile(_arg0);
          reply.writeNoException();
          reply.writeString(_result);
          break;
        }
        default:
        {
          return super.onTransact(code, data, reply, flags);
        }
      }
      return true;
    }
    private static class Proxy implements com.undertalemodtool.avalonia.android.api.IUmApi
    {
      private android.os.IBinder mRemote;
      Proxy(android.os.IBinder remote)
      {
        mRemote = remote;
      }
      @Override public android.os.IBinder asBinder()
      {
        return mRemote;
      }
      public java.lang.String getInterfaceDescriptor()
      {
        return DESCRIPTOR;
      }
      // -- Discovery ---------------------------------------------------------------------------
      // JSON: {ok, apiVersion, appVersion, packageName, descriptor, permission, permissionLevel,
      //        serviceClass, serviceComponent, bindAction, ready, dataLoaded, dataPath, projectName,
      //        runningJobId, activeJobs, scriptRoots[{path, isBuiltIn, exists}]}
      @Override public java.lang.String getApiInfo() throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        java.lang.String _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          boolean _status = mRemote.transact(Stub.TRANSACTION_getApiInfo, _data, _reply, 0);
          _reply.readException();
          _result = _reply.readString();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      // -- Scripts -----------------------------------------------------------------------------
      // JSON: {ok, count, scripts[{name, fileName, relativePath, root, isBuiltIn, fullPath}]}
      @Override public java.lang.String listScripts() throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        java.lang.String _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          boolean _status = mRemote.transact(Stub.TRANSACTION_listScripts, _data, _reply, 0);
          _reply.readException();
          _result = _reply.readString();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      // The three start* methods return JSON: {ok, jobId, state, error}
      // scriptText: the csx source itself (at most 512 KB - Binder transactions are capped at 1 MB).
      // name:       display name / script path used in diagnostics ("inline.csx" when empty).
      // optionsJson may be null; supported keys: {"assumeYes": bool} - the answer the host gives to
      // ScriptQuestion confirmations (default false).
      @Override public java.lang.String startScriptText(java.lang.String scriptText, java.lang.String name, java.lang.String optionsJson) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        java.lang.String _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeString(scriptText);
          _data.writeString(name);
          _data.writeString(optionsJson);
          boolean _status = mRemote.transact(Stub.TRANSACTION_startScriptText, _data, _reply, 0);
          _reply.readException();
          _result = _reply.readString();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      // pathOrUri: a filesystem path, a file:// URI or a content:// URI the app is allowed to read.
      @Override public java.lang.String startScriptFile(java.lang.String pathOrUri, java.lang.String optionsJson) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        java.lang.String _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeString(pathOrUri);
          _data.writeString(optionsJson);
          boolean _status = mRemote.transact(Stub.TRANSACTION_startScriptFile, _data, _reply, 0);
          _reply.readException();
          _result = _reply.readString();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      // relativePath: as returned by listScripts() - resolved inside the built-in script folders
      // and inside the user script folder (/sdcard/QiuUTMTv5/Scripts) only.
      @Override public java.lang.String startBuiltinScript(java.lang.String relativePath, java.lang.String optionsJson) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        java.lang.String _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeString(relativePath);
          _data.writeString(optionsJson);
          boolean _status = mRemote.transact(Stub.TRANSACTION_startBuiltinScript, _data, _reply, 0);
          _reply.readException();
          _result = _reply.readString();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      // -- Jobs --------------------------------------------------------------------------------
      // JSON: {ok, id, kind, name, source, state, queuedAt, startedAt, finishedAt, outputLength,
      //        progress, progressMaximum, progressMessage, progressStatus, returnValue, returnType,
      //        consoleText, error, errorTitle, cancelRequested, assumeYes}
      @Override public java.lang.String getJob(java.lang.String jobId) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        java.lang.String _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeString(jobId);
          boolean _status = mRemote.transact(Stub.TRANSACTION_getJob, _data, _reply, 0);
          _reply.readException();
          _result = _reply.readString();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      // Incremental log read; returns JSON {ok, id, state, offset, nextOffset, eof, text}. The caller
      // passes the nextOffset of the previous call to continue reading. Chunks are cut on char
      // boundaries.
      @Override public java.lang.String getJobOutput(java.lang.String jobId, int fromOffset) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        java.lang.String _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeString(jobId);
          _data.writeInt(fromOffset);
          boolean _status = mRemote.transact(Stub.TRANSACTION_getJobOutput, _data, _reply, 0);
          _reply.readException();
          _result = _reply.readString();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      // Best effort: a queued job stops immediately, a running script stops at its next
      // progress/message call (scripts that never report progress run to completion).
      @Override public boolean cancelJob(java.lang.String jobId) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeString(jobId);
          boolean _status = mRemote.transact(Stub.TRANSACTION_cancelJob, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      // Blocks the calling (Binder) thread until the job finishes or the timeout elapses;
      // returns true when the job has finished. Call it from a worker thread, not from a UI thread.
      @Override public boolean waitForJob(java.lang.String jobId, long timeoutMillis) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeString(jobId);
          _data.writeLong(timeoutMillis);
          boolean _status = mRemote.transact(Stub.TRANSACTION_waitForJob, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      // JSON: {ok, count, jobs[...]} - metadata only, no output text.
      @Override public java.lang.String listJobs() throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        java.lang.String _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          boolean _status = mRemote.transact(Stub.TRANSACTION_listJobs, _data, _reply, 0);
          _reply.readException();
          _result = _reply.readString();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      // Removes all finished jobs from the list, returns how many were removed.
      @Override public int clearFinishedJobs() throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        int _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          boolean _status = mRemote.transact(Stub.TRANSACTION_clearFinishedJobs, _data, _reply, 0);
          _reply.readException();
          _result = _reply.readInt();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      // -- Data files --------------------------------------------------------------------------
      // Both calls block until the file is fully read/written (a large data file can take a while).
      // JSON: {ok, path, dataPath, importantWarnings, warnings[], error}
      @Override public java.lang.String loadDataFile(java.lang.String pathOrUri) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        java.lang.String _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeString(pathOrUri);
          boolean _status = mRemote.transact(Stub.TRANSACTION_loadDataFile, _data, _reply, 0);
          _reply.readException();
          _result = _reply.readString();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      // JSON: {ok, path, dataPath, error}
      @Override public java.lang.String saveDataFile(java.lang.String pathOrUri) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        java.lang.String _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeString(pathOrUri);
          boolean _status = mRemote.transact(Stub.TRANSACTION_saveDataFile, _data, _reply, 0);
          _reply.readException();
          _result = _reply.readString();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
    }
    static final int TRANSACTION_getApiInfo = (android.os.IBinder.FIRST_CALL_TRANSACTION + 0);
    static final int TRANSACTION_listScripts = (android.os.IBinder.FIRST_CALL_TRANSACTION + 1);
    static final int TRANSACTION_startScriptText = (android.os.IBinder.FIRST_CALL_TRANSACTION + 2);
    static final int TRANSACTION_startScriptFile = (android.os.IBinder.FIRST_CALL_TRANSACTION + 3);
    static final int TRANSACTION_startBuiltinScript = (android.os.IBinder.FIRST_CALL_TRANSACTION + 4);
    static final int TRANSACTION_getJob = (android.os.IBinder.FIRST_CALL_TRANSACTION + 5);
    static final int TRANSACTION_getJobOutput = (android.os.IBinder.FIRST_CALL_TRANSACTION + 6);
    static final int TRANSACTION_cancelJob = (android.os.IBinder.FIRST_CALL_TRANSACTION + 7);
    static final int TRANSACTION_waitForJob = (android.os.IBinder.FIRST_CALL_TRANSACTION + 8);
    static final int TRANSACTION_listJobs = (android.os.IBinder.FIRST_CALL_TRANSACTION + 9);
    static final int TRANSACTION_clearFinishedJobs = (android.os.IBinder.FIRST_CALL_TRANSACTION + 10);
    static final int TRANSACTION_loadDataFile = (android.os.IBinder.FIRST_CALL_TRANSACTION + 11);
    static final int TRANSACTION_saveDataFile = (android.os.IBinder.FIRST_CALL_TRANSACTION + 12);
  }
  /** @hide */
  public static final java.lang.String DESCRIPTOR = "com.undertalemodtool.avalonia.android.api.IUmApi";
  // -- Discovery ---------------------------------------------------------------------------
  // JSON: {ok, apiVersion, appVersion, packageName, descriptor, permission, permissionLevel,
  //        serviceClass, serviceComponent, bindAction, ready, dataLoaded, dataPath, projectName,
  //        runningJobId, activeJobs, scriptRoots[{path, isBuiltIn, exists}]}
  public java.lang.String getApiInfo() throws android.os.RemoteException;
  // -- Scripts -----------------------------------------------------------------------------
  // JSON: {ok, count, scripts[{name, fileName, relativePath, root, isBuiltIn, fullPath}]}
  public java.lang.String listScripts() throws android.os.RemoteException;
  // The three start* methods return JSON: {ok, jobId, state, error}
  // scriptText: the csx source itself (at most 512 KB - Binder transactions are capped at 1 MB).
  // name:       display name / script path used in diagnostics ("inline.csx" when empty).
  // optionsJson may be null; supported keys: {"assumeYes": bool} - the answer the host gives to
  // ScriptQuestion confirmations (default false).
  public java.lang.String startScriptText(java.lang.String scriptText, java.lang.String name, java.lang.String optionsJson) throws android.os.RemoteException;
  // pathOrUri: a filesystem path, a file:// URI or a content:// URI the app is allowed to read.
  public java.lang.String startScriptFile(java.lang.String pathOrUri, java.lang.String optionsJson) throws android.os.RemoteException;
  // relativePath: as returned by listScripts() - resolved inside the built-in script folders
  // and inside the user script folder (/sdcard/QiuUTMTv5/Scripts) only.
  public java.lang.String startBuiltinScript(java.lang.String relativePath, java.lang.String optionsJson) throws android.os.RemoteException;
  // -- Jobs --------------------------------------------------------------------------------
  // JSON: {ok, id, kind, name, source, state, queuedAt, startedAt, finishedAt, outputLength,
  //        progress, progressMaximum, progressMessage, progressStatus, returnValue, returnType,
  //        consoleText, error, errorTitle, cancelRequested, assumeYes}
  public java.lang.String getJob(java.lang.String jobId) throws android.os.RemoteException;
  // Incremental log read; returns JSON {ok, id, state, offset, nextOffset, eof, text}. The caller
  // passes the nextOffset of the previous call to continue reading. Chunks are cut on char
  // boundaries.
  public java.lang.String getJobOutput(java.lang.String jobId, int fromOffset) throws android.os.RemoteException;
  // Best effort: a queued job stops immediately, a running script stops at its next
  // progress/message call (scripts that never report progress run to completion).
  public boolean cancelJob(java.lang.String jobId) throws android.os.RemoteException;
  // Blocks the calling (Binder) thread until the job finishes or the timeout elapses;
  // returns true when the job has finished. Call it from a worker thread, not from a UI thread.
  public boolean waitForJob(java.lang.String jobId, long timeoutMillis) throws android.os.RemoteException;
  // JSON: {ok, count, jobs[...]} - metadata only, no output text.
  public java.lang.String listJobs() throws android.os.RemoteException;
  // Removes all finished jobs from the list, returns how many were removed.
  public int clearFinishedJobs() throws android.os.RemoteException;
  // -- Data files --------------------------------------------------------------------------
  // Both calls block until the file is fully read/written (a large data file can take a while).
  // JSON: {ok, path, dataPath, importantWarnings, warnings[], error}
  public java.lang.String loadDataFile(java.lang.String pathOrUri) throws android.os.RemoteException;
  // JSON: {ok, path, dataPath, error}
  public java.lang.String saveDataFile(java.lang.String pathOrUri) throws android.os.RemoteException;
}
